
alert("Your enemy doesn't like the red color in background (CSS), be called Ditto (HTML) and the number 1 and 2 in his dice (JavaScript)");

const player1 = document.querySelector('.nickNamePlayer');
const player2 = document.querySelector('.nickNameEnemie');

const diceP1 = document.querySelector('.diceImg1');
const diceP2 = document.querySelector('.diceImg2');
const btnRoll = document.querySelector('.btn_roll');
const result = document.getElementById('result');


btnRoll.addEventListener('click',function(){

    var colorES = document.getElementsByTagName('body')[0];
    var colresStyle = window.getComputedStyle(colorES);
    var backGC = colresStyle.getPropertyValue('background-color') ;

    var randomNumber = Math.floor(Math.random() * 6) +1 ;      
    diceP1.src = "images/dice"+randomNumber+".png";

    //ENEMY DICE 
    var randomNumber2 = Math.floor(Math.random() * 6) +3 ;     
    //
    diceP2.src = "images/dice"+randomNumber2+".png";
    
    if (randomNumber>randomNumber2){

        if (player2.textContent == "Ditto" && (randomNumber2==1 || randomNumber2 == 2) && backGC == "rgb(255, 0, 0)" ){
            result.innerHTML = "You WIN !";
            console.log(backGC);
        }
    }
    else if (randomNumber == randomNumber2) {
        result.innerHTML = "Roll Again !";
    }
    else{
        result.innerHTML = "You LOSE !";        
        alert("YOU LOSE - Remember Your enemy doesn't like the red color in background (CSS), be called Ditto (HTML) and the number 1 and 2 in his dice (JavaScript)");

    }
});

